## AI Trainer using Computer Vision
### Live Demo: https://advanced-ai-trainer.streamlit.app/
